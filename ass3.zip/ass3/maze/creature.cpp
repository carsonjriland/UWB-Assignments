//
// Created by Yusuf Pisan on 4/18/18.
//

#include "creature.h"
#include <iostream>
#include <string>
using namespace std;
//Shows the creatures current location
ostream& operator<<(ostream& out, const Creature& creature) {
	cout << "Current Creature location row and column: " + to_string(creature.row) + " " + to_string(creature.col);
		return out;
} 

Creature::Creature(int row, int col) : row(row), col(col) {
	//Constructor
}

bool Creature::atExit(const Maze& maze) const {
	if (maze.getExitRow() == row && maze.getExitColumn() == col) { // checks if the creatures current location is at the exit.
		return true;
	}
	else { return false; }
}

string Creature::solve(Maze& maze) { //This method solves the maze and shows the path it took.
	string path;
	path = goNorth(maze);
	if(path == "X"){
		path = goEast(maze);
		if (path == "X") {
			path = goWest(maze);
			if (path == "X") {
				path = goSouth(maze);
			}
		}
	}

	return path;

}
//Checks to see if the square above the creature is open, moves the creature north, and figures out where else to move.
string Creature::goNorth(Maze& maze) { 
	if (maze.isClear(row - 1, col) == true) {
		row = row - 1;
		maze.markAsPath(row, col);
		if (atExit(maze)) {
			return "N";
		}
		else {
			string newPath = goNorth(maze);
			if (newPath == "X") {
				newPath = goEast(maze);
				if (newPath == "X") {
					newPath = goWest(maze);
					if (newPath == "X"){
						maze.markAsVisited(row, col);
						row = row + 1;
						 return goSouth(maze);
					}
				}
			}
			newPath = "N" + newPath;
			return newPath;
		}
	
	}
	else {
		return "X";
	}
	
}
//Checks to see if the square west of the creature is open, moves the creature west, and figures out where else to move.
string Creature::goWest(Maze& maze) {
	if (maze.isClear(row, col - 1) == true) {
		col = col - 1;
		maze.markAsPath(row, col);
		if (atExit(maze)) {
			return "W";
		}
		else {
			string newPath = goNorth(maze);
			if (newPath == "X") {
				newPath = goWest(maze);
				if (newPath == "X") {
					newPath = goSouth(maze);
					if (newPath == "X") {
						maze.markAsVisited(row, col);
						col = col + 1;
						 return goEast(maze);
					}
				}
			}
			newPath = "W" + newPath;
			return newPath;
		}

	}
	else {
		return "X";
	}

}
//Checks to see if the square east of the creature is open, moves the creature east, and figures out where else to move.
string Creature::goEast(Maze& maze) {
	if (maze.isClear(row, col + 1) == true) {
		col = col + 1;
		maze.markAsPath(row, col);
		if (atExit(maze)) {
			return "E";
		}
		else {
			string newPath = goNorth(maze);
			if (newPath == "X") {
				newPath = goEast(maze);
				if (newPath == "X") {
					newPath = goSouth(maze);
					if (newPath == "X") {
						maze.markAsVisited(row, col);
						col = col - 1;
						 return goWest(maze);
					}
				}
			}
			newPath = "E" + newPath;
			return newPath;
		}

	}
	else {
		return "X";
	}
}
//Checks to see if the square below the creature is open, moves the creature south, and figures out where else to move.
string Creature::goSouth(Maze& maze) {
	if (maze.isClear(row + 1, col) == true) {
		row = row + 1;
		maze.markAsPath(row, col);
		if (atExit(maze)) {
			return "S";
		}
		else {
			string newPath = goEast(maze);
			if (newPath == "X") {
				newPath = goSouth(maze);
				if (newPath == "X") {
					newPath = goWest(maze);
					if (newPath == "X") {
						maze.markAsVisited(row, col);
						row = row - 1;
						return goNorth(maze);
					}
				}
			}
			newPath = "S" + newPath;
			return newPath;
		}
	}
	else {
		return "X";
	}
}