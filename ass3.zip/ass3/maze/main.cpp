//
// Created by XXX on YYY.
//

#include <iostream>
#include "creature.h"
#include "maze.h"

void test() {
    Maze M("maze.txt");
    Maze M2("maze2.txt");
    Maze M3("Maze3.txt");
    Creature C(4, 4);
    Creature D(4, 9);
    Creature E(0, 18);
    cout << "Maze Number 1" << endl << C << endl << M << endl;
    cout << "Maze Number 2" << endl << D << endl << M2 << endl;
    cout << "Maze Number 3" << endl << E << endl << M3 << endl;
    cout << "Path: " << C.solve(M) << endl;
    cout << M << endl;
    cout << "Path: " << D.solve(M2) << endl;
    cout << M2 << endl;
    cout << "Path: " << E.solve(M3) << endl;
    cout << M3 << endl;

}

int main() {
    test();
    cout << "Done!" << std::endl;
    return 0;
}